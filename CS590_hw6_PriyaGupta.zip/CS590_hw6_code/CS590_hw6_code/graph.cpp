#include "graph.h"
#include <list>
#include <iostream>

using namespace std;

/*
 * constructor/destructor
 */
graph::graph(int n)
{ /*<<<*/
  no_vert = (n > 0) ? n : 1;

/*
 * allocate adjacency matrix
 */
  m_edge = new int*[no_vert];
  for (int i = 0; i < no_vert; i++)
    m_edge[i] = new int[no_vert];

  initialize();
} /*>>>*/

graph::~graph()
{ /*<<<*/ 
/*
 * delete nil element and all other allocated nodes
 */
  for (int i = 0; i < no_vert; i++)
    delete[] m_edge[i];
  delete[] m_edge;
} /*>>>*/


void graph::initialize()
{ /*<<<*/
/*
 * initialize adjacency matrix
 * -> use infinity to allow 0 weight edges
 */
  for (int i = 0; i < no_vert; i++)
    for (int j = 0; j < no_vert; j++)
      m_edge[i][j] = INT_MAX;

} /*>>>*/

void graph::permutation(int* perm, int n)
{ /*<<<*/
  random_generator rg;
  int p_tmp, p_pos;

  for (int i = 0; i < n; i++)
    perm[i] = i;
  
  for (int i = 0; i < n; i++)
    {
      rg >> p_pos;
      p_pos = (p_pos % (n - i)) + i;

      p_tmp = perm[i];
      perm[i] = perm[p_pos];
      perm[p_pos] = p_tmp;
    }
} /*>>>*/

void graph::output(int** m_out, int** m_out_2)
{ /*<<<*/
  if (!m_out)
    m_out = m_edge;

  cout << "[";
  for (int i = 0; i < no_vert; i++)
    {
      cout << "[\t";
      for (int j = 0; j < no_vert; j++)
  if (m_out[i][j] == INT_MAX)
    cout << "inf\t";
  else
    cout << m_out[i][j] << "\t";

      if (m_out_2)
  {
    cout << "]\t\t[\t";
    for (int j = 0; j < no_vert; j++)
      if (m_out_2[i][j] == INT_MAX)
        cout << "inf\t";
      else
        cout << m_out_2[i][j] << "\t";
  }

      cout << "]" << endl;
    }
  cout << "]" << endl;
} /*>>>*/


// TODO: Implement problem 1
void graph::generate_random(int edges, int weight)
{
  random_generator generate_graph;
  int *edge_weight = new int(no_vert);

  if (edges <= 0)
  {
    cout << "number of edges cannot be less than 1" << endl;
    return;
  }

  if (edges > (no_vert * no_vert - no_vert))
  {
    cout << "Maximum number of edges for " << no_vert << " vertices should be : " << (no_vert * no_vert - no_vert) << endl;
    return;
  }

  while (!edges_complete(edges))
  {
    permutation(edge_weight, no_vert);
    int i = 0;
    while (i < (no_vert - 2) && !edges_complete(edges))
    {
      int u = edge_weight[i];
      int v = edge_weight[i + 1];
      if (m_edge[u][v] == INT_MAX)
      {
        random_generator generate_graph;
        int randomWeight = 0;
        generate_graph >> randomWeight;
        randomWeight = randomWeight % (2 * weight + 1) + (-weight);
        m_edge[u][v] = randomWeight;
      }
      i = i + 1;
    }
  }
  delete edge_weight;

}

bool graph::edges_complete(int n_edges)
{ /*<<<*/
  int count = 0;
  for (int i = 0; i < no_vert; i++)
    for (int j = 0; j < no_vert; j++)
      if (m_edge[i][j] != INT_MAX)
        count = count + 1;

  if (count == n_edges)
    return true;
  else
    return false;
} /*>>>*/


// TODO: Implement problem 3
bool graph::bellman_ford(int s, int*& v_d, int*& v_pi)
{
   if (s > no_vert - 1 || s < 0)
  {
    cout << "Please enter a valid source node." << endl;
    return false;
  }

  v_d = new int[no_vert];
  v_pi = new int[no_vert];

  for (int i = 0; i < no_vert; i++)
  {
    v_d[i] = INT_MAX;
    v_pi[i] = INT_MAX;
  }
  v_d[s] = 0;

    int count = 0;
    while (count < no_vert)
      {
        int i = s + 1;
        int edge_count = 0;
        while (edge_count < no_vert)
        {
          i = i % no_vert;
          for (int j = 0; j < no_vert; j++)
          {
            if (m_edge[i][j] != INT_MAX)
            {
              if (v_d[i] != INT_MAX && (v_d[j] > (v_d[i] + m_edge[i][j])))
              {
                v_d[j] = v_d[i] + m_edge[i][j];
                v_pi[j] = i;
              }
            }
          }
          i = i + 1;
          edge_count = edge_count + 1;
        }
        count = count + 1;
      }

  //Takes ~O~(E) (theta of E)
  for (int i = 0; i < no_vert; i++)
  {
    for (int j = 0; j < no_vert; j++)
    {
      if (m_edge[i][j] != INT_MAX)
      {
        if (v_d[j] > v_d[i] + (m_edge[i][j]))
        {
          return true;
        }
      }
    }
  }
  return true;
}



// TODO: Implement problem 4
void graph::floyd_warshall(int**& d, int**& pi)
{
  d = new int *[no_vert];
  pi = new int *[no_vert];

  for (int i = 0; i < no_vert; i++)
  {
    d[i] = new int[no_vert];
    pi[i] = new int[no_vert];
  }

  for (int i = 0; i < no_vert; i++)
    for (int j = 0; j < no_vert; j++)
    {
      if (i != j && m_edge[i][j] < INT_MAX)
      {
        pi[i][j] = i;
      }
      else
      {
        pi[i][j] = INT_MAX;
      }
    }

  for (int i = 0; i < no_vert; i++)
    for (int j = 0; j < no_vert; j++)
      if (i != j)
        d[i][j] = m_edge[i][j];
      else
        d[i][j] = 0;

  for (int k = 0; k < no_vert; k++)
  {
    for (int i = 0; i < no_vert; i++)
    {
      for (int j = 0; j < no_vert; j++)
      {
        if (d[i][k] != INT_MAX && d[k][j] != INT_MAX)
        {
          if ((d[i][k] + d[k][j]) < d[i][j])
          {
            d[i][j] = d[i][k] + d[k][j];
            pi[i][j] = pi[k][j];
          }
        }
      }
    }
  }

}
