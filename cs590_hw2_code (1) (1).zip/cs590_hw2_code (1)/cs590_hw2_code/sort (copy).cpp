#include <cstdio>
#include <string>
using std::string;
#include<iostream>
#include <string>
using namespace std;

#include <cstdio>
#include <string>

#include "sort.h"

/* 
 * HW 2 part
 */
int string_compare(char* s1, char *s2)
{ 
/*
 * We assume that s1 and s2 are non-null pointers
 */
  int i;

  i = 0;
  while ((s1[i] != 0) && (s2[i] != 0) && (s1[i] == s2[i]))
    i++;

  if (s1[i] == s2[i])
    return 0;
  else
    {
      if (s1[i] < s2[i])
	return -1;
      else
	return 1;
    }
} /*>>>*/

void insertion_sort(char** A, int l, int r)
{ 
  int i;
  char* key;

  for (int j = l+1; j <= r; j++)
    {
      key = A[j];
      i = j - 1;

      while ((i >= l) && (string_compare(A[i], key) > 0))
        {
	  A[i+1] = A[i];
	  i = i - 1;
	}

      A[i+1] = key;
    }
}

int compare_string(char a, char b){
  cout << "in compare" <<"";
  if(a==b){
    return 0;
  }
  else {if(a<b){
    return -1;
  }
  else{
    return 1;
  }}

}

void insertion_sort_digit(char** A, int* A_len, int l, int r, int d)
{
  int i;
  char *key;
  int temp_len ;
  char input = '0';


  for (int j = l+1; j < r; j++)
    {
      input ='0';
      
      if(A_len[j] >= d){
        input = A[j][d];
      }

      key = A[j];
      temp_len = A_len[j];
      i = j - 1;

      while ((i >= l) &&  A_len[i]>=d &&(compare_string(A[i][d], input)>0))
        {
          A[i+1] = A[i];
          A_len[i+1] = A_len[i];

          i = i - 1;
	}

      A[i+1] = key;
      A_len[i+1] = temp_len;
    }
}

size_t getMax(int* A_len, int n){
     int max = A_len[0];
    	for (int i = 1; i < n; i++){
        // cout<<input_array[i]<< "    "<<input_length[i]<<"    ";
        if(max < A_len[i]){
          max = A_len[i];
        }
    }
   return max;
}

void counting_sort_digit(char** A, int* A_len, char** B, int* B_len, int n, int d)
{
  
}

void radix_sort_is(char** A, int* A_len, int n, int m)
{ 
  int max = getMax(A_len, n);
    for (int digit = max; digit >= 0; digit--)
    { // size_t is unsigned, so avoid using digit >= 0, which is always true
     std::cout<< digit << std::endl;
       insertion_sort_digit(A,A_len,0,n,max);
    }

}

void radix_sort_cs(char** A, int* A_len, int n, int m)
{ 
  
}

/*
 * Simple function to check that our sorting algorithm did work
 * -> problem, if we find position, where the (i-1)-th element is 
 *    greater than the i-th element.
 */
bool check_sorted(char** A, int l, int r)
{
  for (int i = l+1; i < r; i++)
    if (string_compare(A[i-1],A[i]) > 0)
      return false;
  return true;
}
