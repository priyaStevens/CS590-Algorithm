#include <cstdio>
#include <string>
using std::string;
#include<iostream>
#include <string>
using namespace std;

#include <cstdio>
#include <string>

#include "sort.h"
#include <list>

/* 
 * HW 2 part
 */
int string_compare(char* s1, char *s2)
{ 
/*
 * We assume that s1 and s2 are non-null pointers
 */
  int i;

  i = 0;
  while ((s1[i] != 0) && (s2[i] != 0) && (s1[i] == s2[i]))
    i++;

  if (s1[i] == s2[i])
    return 0;
  else
    {
      if (s1[i] < s2[i])
	return -1;
      else
	return 1;
    }
} /*>>>*/

void insertion_sort(char** A, int l, int r)
{ 
  int i;
  char* key;

  for (int j = l+1; j <= r; j++)
    {
      key = A[j];
      i = j - 1;

      while ((i >= l) && (string_compare(A[i], key) > 0))
        {
	  A[i+1] = A[i];
	  i = i - 1;
	}

      A[i+1] = key;
    }
}

int compare_string(char a, char b){
  
  if(a==b){
    return 0;
  }
  else {if(a<b){
    return -1;
  }
  else{
    return 1;
  }}

}

void insertion_sort_digit(char **A, int *A_len, int l, int r, int d)
{
  int i;
  char *key;
  char value = '0' ;
  int temp_len;


  for (int j = l+1; j < r; j++)
    {
      value ='0';
      
      if(A_len[j] >= d){
        value = A[j][d];
      }

      key = A[j];
      temp_len = A_len[j];
      i = j - 1;

      while ((i >= l) &&  A_len[i] >= d && (compare_string(A[i][d], value)>0))
        {
          A[i+1] = A[i];
          A_len[i+1] = A_len[i];

          i = i - 1;
	}

      A[i+1] = key;
      A_len[i+1] = temp_len;
    }
}

size_t getMax(int* A_len, int n){
     int max = A_len[0];
    	for (int i = 1; i < n; i++){
        // cout<<input_array[i]<< "    "<<input_length[i]<<"    ";
        if(max < A_len[i]){
          max = A_len[i];
        }
    }
   return max;
}

void counting_sort_digit(char** A, int* A_len, char** B, int* B_len, int n, int d)
{
    list<char*> listItem[27]; 
    list<int> listlen[27]; 
     

    for (int j = 0; j < n; j++)
    {
      int index_val = 0;

      if(A_len[j] >= d){
        
        int value = (int)A[j][d-1];
        index_val= value - 97+1;
      }

        listItem[index_val].push_back(A[j]);
        listlen[index_val].push_back(A_len[j]);
    }

    int bindex = 0;

    for(int i=0; i<27; i++){
      while(!listItem[i].empty() && !listlen[i].empty()){
        B[bindex] = *(listItem[i].begin());
        B_len[bindex] = *(listlen[i].begin());
        listItem[i].erase(listItem[i].begin());
        listlen[i].erase(listlen[i].begin());

        bindex++;
      }
      
    }

    for(int i=0; i<n; i++){
      A[i] = B[i];
      A_len[i] = B_len[i];
    }
    
  
}

void radix_sort_is(char** A, int* A_len, int n, int m)
{ 

  int max = getMax(A_len, n);
    while(max >= 0){
      insertion_sort_digit(A,A_len, 0 , n,max);
      for(int i=0; i<n; i++){
			// cout<< max<<" " << A[i] << "  "<< A_len[i] <<"  ";
		}
      max --;
    }

}

void radix_sort_cs(char** A, int* A_len, int n, int m)
{ 
  char** B ;
  int* B_len;

  while(m>0){
  B = new char*[n];
  B_len = new int[n];
  counting_sort_digit(A,A_len, B, B_len, n,m);
  m = m-1;
   
  delete[] B;
  delete[] B_len;

  }
      
}

/*
 * Simple function to check that our sorting algorithm did work
 * -> problem, if we find position, where the (i-1)-th element is 
 *    greater than the i-th element.
 */
bool check_sorted(char** A, int l, int r)
{
  for (int i = l+1; i < r; i++)
    if (string_compare(A[i-1],A[i]) > 0)
      return false;
  return true;
}
