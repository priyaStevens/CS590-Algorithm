
#include "bs_tree.h"
#include <list>
#include <iostream>

using namespace std;

/*
 * constructor/destructor
 */
bs_tree::bs_tree()
{ 

} 

bs_tree::~bs_tree()
{ 

} 

void bs_tree::insert(int key, bs_tree_i_info& t_info)
{ 

}

// TODO: modified inorder tree walk method to save the 
// sorted numbers in the first argument: int* array.
// question 2
int bs_tree::convert(int* array, int n)
{
  return n;
}



