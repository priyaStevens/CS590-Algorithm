#include "graph.h"
#include <iostream>
#include <queue>
#include <set>
#include "graph.h"


//construct a graph using node.
Graph::Graph(int n)
{
    if ( n <= 0){
        cout<<"Please enter valid node numbers for graph "<<endl;
        return;
    }
    this->nodes = n; 
    this->matrix = new int*[nodes];

    //Initialization of the adjacency matrix
    for (int i = 0; i < nodes; i++){
        matrix[i] = new int[nodes];
        for (int j = 0; j < nodes; j++)
        {
            matrix[i][j] = 0;
        }
    }
}

//Construct agraph with adjacency matrix and nodes
Graph::Graph(int** adj, int n)
{
    if ( n < 1){
        cout<<"Please enter 1 or more number of nodes."<<endl;
        return;
    }
    this->nodes = n;
    this->matrix = new int*[nodes];

    //Setting values in adjacency matrix
    for (int i = 0; i < nodes; i++){
        matrix[i] = new int[nodes];
        for (int j = 0; j < nodes; j++)
        {
            matrix[i][j] = adj[i][j];
        }
    }
}

Graph::~Graph()
{
  for (int i = 0; i < nodes; i++)
    delete[] matrix[i];
  delete[] matrix;

}

//set the value for edges
bool Graph::set_edge(int u,int v, int w)
{
    if(u<0 || u>nodes-1 || v<0 || v>nodes-1){
        cout<<"Please enter valid node"<<endl;
        return false;
    }
    else{
        matrix[u][v] = w;
        return true;
    }
    
}
 
//implementing bfs
void Graph::bfs(int source)
{ 
    if ( source > nodes - 1 || source < 0 ){
        cout<<"Please enter a valid source to start bfs"<<endl;
        return;
    }
    set <int>* visited;
    bfs(source,visited);

}

//implementing bfs helper function
void Graph::bfs(int source, set<int>* visited){
    visited  = new set<int>;
    queue<int> q;

    visited->insert(source);

    cout<<"bfs nodes in order they are visited" <<endl;
    //cout << source << endl;

    q.push(source);

    while(!q.empty()){
        int u = q.front();
        cout << u <<" ";
        q.pop();

        for (int v = 0; v < nodes; v++){
            if (matrix[u][v] > 0 && visited->count(v)==0) {
                visited->insert(v);              
                q.push(v);
                // cout << "->" <<endl;
            }
        }

    }
     delete visited;
}

//implemeting dfs
void Graph::dfs()
{
    int source  = matrix[0][0];
    // int source  = 8;
    cout<< "source"<<source<<endl;
    if ( source > nodes - 1 || source < 0 ){
        cout<<"Please enter a valid source to start dfs."<<endl;
        return;
    }

    set <int>* visited = new set<int>;;
 
    cout<<"dfs nodes in order they are visited" <<endl;
    dfs(source,visited);
    delete visited;
}

void Graph::dfs(int source, set<int>* visited) {
    cout<<source<<endl;
    visited->insert(source);
    for (int i = 0; i < nodes; i++){
        if (matrix[source][i] > 0 && visited->count(i)==0) {
            dfs(i,visited);
        }
    }
}


